package com.example.aula6

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.example.aula6.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var mensagem: String
    private val TAG = "estado"
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)
        Log.d(TAG, "onCreate invocado")

        mensagem = "salve!"
    }

    override fun onStart() {
        super.onStart()
        binding.txtMensagem.text = mensagem
        Log.d(TAG, "onStart invocado")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume invocado")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "onPause invocado")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "onStop invocado")
    }

    override fun onRestart() {
        super.onRestart()
        mensagem = "Salve de novo!2"
        Log.d(TAG, "onRestart invocado")
    }


}