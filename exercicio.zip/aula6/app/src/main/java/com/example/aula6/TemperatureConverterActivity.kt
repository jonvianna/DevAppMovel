package com.example.aula6

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.aula6.databinding.ActivityTemperatureConverterBinding

class TemperatureConverterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTemperatureConverterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTemperatureConverterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnConvert.setOnClickListener {
            convertTemperature()
        }
    }

    private fun convertTemperature() {
        val celsius = binding.editTextCelsius.text.toString().toDoubleOrNull()

        if (celsius != null) {
            val fahrenheit = (9 * celsius + 160) / 5
            binding.textViewFahrenheit.text = "Temperatura em Fahrenheit: $fahrenheit °F"
        } else {
            binding.textViewFahrenheit.text = "Entrada inválida"
        }
    }
}
