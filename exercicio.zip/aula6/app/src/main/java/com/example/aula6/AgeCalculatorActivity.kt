package com.example.aula6

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.aula6.databinding.ActivityAgeCalculatorBinding
import java.util.*

class AgeCalculatorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAgeCalculatorBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAgeCalculatorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnCalculateAge.setOnClickListener {
            calculateAge(binding.editTextYearOfBirth.text.toString())
        }
    }

    private fun calculateAge(yearOfBirthText: String) {
        val currentYear = Calendar.getInstance().get(Calendar.YEAR)
        val yearOfBirth = yearOfBirthText.toIntOrNull()

        if (yearOfBirth != null && yearOfBirth >= 1900 && yearOfBirth <= currentYear) {
            val age = currentYear - yearOfBirth
            binding.textViewAge.text = "Idade: $age"
        } else {
            binding.textViewAge.text = "Data de nascimento inválida"
        }
    }
}
