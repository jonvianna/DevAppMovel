package com.example.aula6

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.aula6.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnUm.setOnClickListener {
            val intent = Intent(this, SalaryIncreaseActivity::class.java)
            startActivity(intent)
        }

        binding.btnDois.setOnClickListener {
            val intent = Intent(this, VolumeCalculatorActivity::class.java)
            startActivity(intent)
        }

        binding.btnTres.setOnClickListener {
            val intent = Intent(this, AgeCalculatorActivity::class.java)
            startActivity(intent)
        }

        binding.btnQuatro.setOnClickListener {
            val intent = Intent(this, FuelConsumptionActivity::class.java)
            startActivity(intent)
        }

        binding.btnCinco.setOnClickListener {
            val intent = Intent(this, GradeCalculatorActivity::class.java)
            startActivity(intent)
        }

        binding.btnSeis.setOnClickListener {
            val intent = Intent(this, TemperatureConverterActivity::class.java)
            startActivity(intent)
        }

        binding.btnSete.setOnClickListener {
            val intent = Intent(this, OilCanVolumeCalculatorActivity::class.java)
            startActivity(intent)
        }
    }
}
